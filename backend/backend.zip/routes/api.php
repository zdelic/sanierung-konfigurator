<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;

// PUBLIC
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login', [AuthController::class, 'login']);

// PROTECTED
Route::middleware('auth:sanctum')->group(function () {

    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    // samo admin
    Route::middleware('role:admin')->group(function () {
        // npr. user management rute
        // Route::get('/admin/users', ...);
    });

    // ko ima permission pricebook.edit (admin i eventualno neko drugi)
    Route::middleware('permission:pricebook.edit')->group(function () {
        // npr. pricebook update rute
        // Route::post('/pricebook/items', ...);
        // Route::put('/pricebook/items/{id}', ...);
    });

    // svi koji mogu edit projekte
    Route::middleware('permission:projects.edit')->group(function () {
        // Route::post('/projects', ...);
        // Route::put('/projects/{id}', ...);
    });
});
