import type { PricebookItemDTO, PricebookItemMap } from "@/lib/pricebook/types";
import { num } from "@/lib/pricebook/client";
import type { RangePrice } from "./fenster.pricebook";

export type FensterPriceBook = {
  servicieren: { title: string; description?: string; ranges: RangePrice[] };

  sanierung_bestandsfenster: {
    title: string;
    description?: string;
    base: number;
    ratePerM2: number;
    minM2: number;
  };
  sanierung_bestandskastenfenster: {
    title: string;
    description?: string;
    base: number;
    ratePerM2: number;
    minM2: number;
  };
  aufz_prallscheibe: {
    title: string;
    description?: string;
    base: number;
    ratePerM2: number;
    minM2: number;
  };

  // ✅ FLAT konfigurator fields (tačno kako fenster.calc.ts očekuje)
  grundpauschale_fenstertausch: number;
  abbruch_bestehender_fenster_per_m2: number;

  typ_holz_alu_per_m2: number;
  typ_pvc_alu_per_m2: number;
  typ_pvc_per_m2: number;

  blindstock_per_m2: number;
  mehrteiligkeit_per_m2: number;

  schallschutz_43db_per_m2: number;
  nicht_transparent_per_m2: number;
  oberlichte_per_m2: number;

  luefter_per_stk: number;

  abbruch_sonnenschutz_per_m2: number;

  montage_innenjalousien_per_m2: number;
  montage_aussenjalousien_per_m2: number;
  montage_blinos_rollo_per_m2: number;

  aufz_sonnenschutz_aufputz_per_m2: number;
};

function req(map: PricebookItemMap, key: string): PricebookItemDTO {
  const it = map[key];
  if (!it) throw new Error(`Missing pricebook item "${key}"`);
  return it;
}

function parseRangeToken(token: string) {
  if (token.endsWith("_plus")) {
    const min = Number(token.replace("_plus", ""));
    return { min: Number.isFinite(min) ? min : 0, max: null as number | null };
  }
  const [a, b] = token.split("_");
  return { min: Number(a), max: Number(b) };
}

function buildRanges(map: PricebookItemMap, prefix: string): RangePrice[] {
  return Object.keys(map)
    .filter((k) => k.startsWith(prefix))
    .map((k) => {
      const token = k.slice(prefix.length);
      const { min, max } = parseRangeToken(token);
      return { min, max, price: num(req(map, k).grundpreis) };
    })
    .sort((a, b) => (a.min ?? 0) - (b.min ?? 0));
}

function baseRate(map: PricebookItemMap, key: string, minM2 = 1) {
  const it = req(map, key);
  return {
    title: it.title,
    description: it.description ?? undefined,
    base: num(it.grundpreis),
    ratePerM2: num(it.unitprice),
    minM2,
  };
}

export function buildFensterPricebook(map: PricebookItemMap): FensterPriceBook {
  const anyServ = req(map, "servicieren.ranges.0_40");

  return {
    servicieren: {
      title: anyServ.title.replace(/\s*\(\d.*\)$/, ""),
      description: anyServ.description ?? undefined,
      ranges: buildRanges(map, "servicieren.ranges."),
    },

    sanierung_bestandsfenster: baseRate(map, "sanierung_bestandsfenster", 1),
    sanierung_bestandskastenfenster: baseRate(
      map,
      "sanierung_bestandskastenfenster",
      1,
    ),
    aufz_prallscheibe: baseRate(map, "aufz_prallscheibe", 1),

    // ---- mapiranje konfiguratora iz DB keys
    grundpauschale_fenstertausch: num(
      req(map, "konfigurator.grundpauschale").grundpreis,
    ),

    abbruch_bestehender_fenster_per_m2: num(
      req(map, "konfigurator.abbruch_bestehender_fenster").unitprice,
    ),

    typ_holz_alu_per_m2: num(req(map, "konfigurator.typ.holz_alu").unitprice),
    typ_pvc_alu_per_m2: num(req(map, "konfigurator.typ.pvc_alu").unitprice),
    typ_pvc_per_m2: num(req(map, "konfigurator.typ.pvc").unitprice),

    blindstock_per_m2: num(req(map, "konfigurator.aufz.blindstock").unitprice),
    mehrteiligkeit_per_m2: num(
      req(map, "konfigurator.aufz.mehrteiligkeit").unitprice,
    ),

    schallschutz_43db_per_m2: num(
      req(map, "konfigurator.aufz.schallschutz_43db").unitprice,
    ),
    nicht_transparent_per_m2: num(
      req(map, "konfigurator.aufz.nicht_transparent").unitprice,
    ),
    oberlichte_per_m2: num(req(map, "konfigurator.aufz.oberlichte").unitprice),

    luefter_per_stk: num(req(map, "konfigurator.luefter").unitprice),

    abbruch_sonnenschutz_per_m2: num(
      req(map, "konfigurator.sonnenschutz.abbruch").unitprice,
    ),

    montage_innenjalousien_per_m2: num(
      req(map, "konfigurator.sonnenschutz.montage.innenjalousien").unitprice,
    ),
    montage_aussenjalousien_per_m2: num(
      req(map, "konfigurator.sonnenschutz.montage.aussenjalousien").unitprice,
    ),
    montage_blinos_rollo_per_m2: num(
      req(map, "konfigurator.sonnenschutz.montage.blinos").unitprice,
    ),

    aufz_sonnenschutz_aufputz_per_m2: num(
      req(map, "konfigurator.sonnenschutz.aufputz").unitprice,
    ),
  };
}
