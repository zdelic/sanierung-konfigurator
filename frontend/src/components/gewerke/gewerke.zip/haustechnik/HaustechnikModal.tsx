// HaustechnikModal.tsx
import Modal from "../../Modal";
import {
  HST_PRICEBOOK as pb,
  clamp0,
  formatEUR,
} from "./haustechnik.pricebook";
import {
  calcHaustechnikParts,
  type HaustechnikState,
  type BelagChoice,
} from "./haustechnik.calc";

import type { AbbruchState } from "../aabbruch/abbruch.calc";
import type { BodenState } from "../boden/boden.calc";
import type { FliesenState } from "../fliesen/fliesen.calc";
import type { EstrichState } from "../estrich/estrich.calc";

function Switch(props: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={() => !props.disabled && props.onChange(!props.checked)}
      className={[
        "h-7 w-12 rounded-full p-1 ring-1 transition",
        props.disabled ? "opacity-50 cursor-not-allowed" : "",
        props.checked
          ? "bg-emerald-500/30 ring-emerald-400/30"
          : "bg-white/10 ring-white/15",
      ].join(" ")}
      aria-label="toggle"
    >
      <div
        className={[
          "h-5 w-5 rounded-full bg-white transition",
          props.checked ? "translate-x-5" : "translate-x-0",
        ].join(" ")}
      />
    </button>
  );
}

function ToggleRow(props: {
  title: string;
  description?: string;
  checked: boolean;
  price: number;
  disabled?: boolean;
  onToggle: (v: boolean) => void;
  extraRight?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <div
      className={[
        "rounded-3xl bg-white/5 p-4 ring-1 ring-white/10",
        props.disabled ? "opacity-60" : "",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-sm font-semibold whitespace-pre-line">
            {props.title}
          </div>
          {props.description ? (
            <div className="mt-1 text-xs text-slate-400 whitespace-pre-line">
              {props.description}
            </div>
          ) : null}
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {props.extraRight}
          <div className="text-sm font-semibold">{formatEUR(props.price)}</div>
          <Switch
            checked={props.checked}
            disabled={props.disabled}
            onChange={props.onToggle}
          />
        </div>
      </div>

      {props.checked && props.children ? (
        <div className="mt-3">{props.children}</div>
      ) : null}
    </div>
  );
}

function QtyInput(props: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  step?: number;
  unitBadge?: string;
}) {
  const step = props.step ?? 1;
  return (
    <label className="block">
      <div className="text-xs text-slate-400">{props.label}</div>
      <div className="mt-2 flex items-center gap-2">
        <input
          type="number"
          min={0}
          step={step}
          value={props.value}
          onKeyDown={(e) => {
            if (e.key === "-" || e.key === "ArrowDown") e.preventDefault();
          }}
          onChange={(e) => {
            const v = Number(e.target.value);
            if (!Number.isFinite(v)) return;
            props.onChange(Math.max(0, v));
          }}
          className="w-full rounded-2xl bg-white/5 px-4 py-3 text-sm ring-1 ring-white/10 outline-none focus:ring-white/20"
        />
        {props.unitBadge ? (
          <span className="inline-flex items-center rounded-full bg-white/10 px-2.5 py-1 text-[11px] text-slate-200 ring-1 ring-white/15">
            {props.unitBadge}
          </span>
        ) : null}
      </div>
    </label>
  );
}

export default function HaustechnikModal(props: {
  open: boolean;
  wohnflaecheM2: number;
  value: HaustechnikState;
  onChange: (next: HaustechnikState) => void;

  // cross-gewerk states
  abbruch: AbbruchState;
  onAbbruchChange: (next: AbbruchState) => void;

  boden: BodenState;
  onBodenChange: (next: BodenState) => void;

  fliesen: FliesenState;
  onFliesenChange: (next: FliesenState) => void;

  estrich: EstrichState;
  onEstrichChange: (next: EstrichState) => void;

  onClose: () => void;
}) {
  const s = props.value;
  const m2 = clamp0(props.wohnflaecheM2);
  const parts = calcHaustechnikParts(props.wohnflaecheM2, s);

  // -----------------------------
  // Auto-dependency plumbing
  // -----------------------------
  function withAutoDeps(next: HaustechnikState): HaustechnikState {
    // 1) Befund is required whenever any dependent position is on.
    const requiresBefund =
      next.heizkoerperOn ||
      next.heizleitungenOn ||
      next.sockelkanalOn ||
      next.fbhOn ||
      next.kuehlHeizdeckeOn ||
      next.filtertauschOn ||
      next.ventilatorOn ||
      next.lueftungszuleitungOn ||
      next.badGesamtOn ||
      next.fallstrangOn ||
      next.kuecheAufputzOn ||
      next.aufzSprossenOn ||
      next.aufzHaengeWCOn ||
      next.aufzDuschtasseOn ||
      next.behindertOn ||
      next.gasPruefungOn ||
      next.gasServiceOn ||
      next.gasThermeNeuOn ||
      next.gasInnenleitungenOn ||
      next.gaszuleitungOn ||
      next.zaehlerplatteOn;

    if (requiresBefund && !next.befundOn) {
      next = {
        ...next,
        befundOn: true,
        befundSource: next.befundSource ?? "auto",
      };
    }

    if (!requiresBefund && next.befundOn && next.befundSource === "auto") {
      next = { ...next, befundOn: false, befundSource: null };
    }

    // 2) Heizkörper is required whenever Heizleitungen/Sockelkanal/FBH is on.
    const requiresHeizkoerper =
      next.heizleitungenOn || next.sockelkanalOn || next.fbhOn;

    if (requiresHeizkoerper && !next.heizkoerperOn) {
      next = {
        ...next,
        heizkoerperOn: true,
        heizkoerperSource: next.heizkoerperSource ?? "auto",
        // User still must accept the Hinweis manually
        heizkoerperDepsAccepted: false,
      };
    }

    if (
      !requiresHeizkoerper &&
      next.heizkoerperOn &&
      next.heizkoerperSource === "auto"
    ) {
      next = {
        ...next,
        heizkoerperOn: false,
        heizkoerperSource: null,
        heizkoerperDepsAccepted: false,
      };
    }

    return next;
  }

  const update = (patch: Partial<HaustechnikState>) => {
    const merged = { ...s, ...patch } as HaustechnikState;
    props.onChange(applyAutoDeps(merged));
  };

  // -----------------------------
  // Cross-Gewerk auto-dependency helpers (ref-count)
  // -----------------------------
  function bumpAbbruchBelag(delta: number) {
    const cur = props.abbruch;
    const nextCount = Math.max(0, (cur.belagAutoCount ?? 0) + delta);

    // If user already picked teil/voll -> treat as manual (do not override)
    const isManual = cur.belagMode !== "off" && cur.belagSource !== "auto";

    let belagMode = cur.belagMode;
    let belagSource = cur.belagSource ?? null;

    // auto ON
    if (nextCount > 0 && belagMode === "off" && !isManual) {
      belagMode = "voll";
      belagSource = "auto";
    }

    // auto OFF (only if it was auto)
    if (nextCount === 0 && belagMode !== "off" && belagSource === "auto") {
      belagMode = "off";
      belagSource = null;
    }

    props.onAbbruchChange({
      ...cur,
      belagAutoCount: nextCount,
      belagMode,
      belagSource,
    });
  }

  function bumpAbbruchEstrich(delta: number) {
    const cur = props.abbruch;
    const nextCount = Math.max(0, (cur.estrichAutoCount ?? 0) + delta);

    const isManual = cur.estrichMode !== "off" && cur.estrichSource !== "auto";

    let estrichMode = cur.estrichMode;
    let estrichSource = cur.estrichSource ?? null;

    if (nextCount > 0 && estrichMode === "off" && !isManual) {
      estrichMode = "voll";
      estrichSource = "auto";
    }

    if (nextCount === 0 && estrichMode !== "off" && estrichSource === "auto") {
      estrichMode = "off";
      estrichSource = null;
    }

    props.onAbbruchChange({
      ...cur,
      estrichAutoCount: nextCount,
      estrichMode,
      estrichSource,
    });
  }

  // Estrich Neu 6cm (and its Abbruch dependencies)
  function bumpEstrichNeu(delta: number, autoAcceptDeps: boolean) {
    const cur = props.estrich;
    const nextCount = Math.max(0, (cur.neuAutoCount ?? 0) + delta);

    const isManual = cur.neuOn && cur.neuSource !== "auto";

    let neuOn = cur.neuOn;
    let neuSource = cur.neuSource ?? null;

    // auto ON
    if (nextCount > 0 && !neuOn && !isManual) {
      neuOn = true;
      neuSource = "auto";
    }

    // auto OFF (only if auto)
    if (nextCount === 0 && neuOn && neuSource === "auto") {
      // if we previously held Abbruch deps via depsAccepted, release them
      if (cur.depsAccepted) {
        bumpAbbruchEstrich(-1);
        bumpAbbruchBelag(-1);
      }

      props.onEstrichChange({
        ...cur,
        neuAutoCount: nextCount,
        neuOn: false,
        neuSource: null,
        depsAccepted: false,
        beschleunigerOn: false,
      });
      return;
    }

    // keep state + update count/source
    props.onEstrichChange({
      ...cur,
      neuAutoCount: nextCount,
      neuOn,
      neuSource,
      depsAccepted: autoAcceptDeps ? true : cur.depsAccepted,
    });

    // dependency-of-dependency:
    // Neuherstellung Estrich 6cm requires Abbruch: Estrich + Belag
    if (autoAcceptDeps && !cur.depsAccepted) {
      bumpAbbruchEstrich(+1);
      bumpAbbruchBelag(+1);
    }
  }

  function ensureFliesenBadWc() {
    if (props.fliesen.neuBadWcOn && props.fliesen.neuBadWcDepsAccepted) return;
    props.onFliesenChange({
      ...props.fliesen,
      neuBadWcOn: true,
      neuBadWcDepsAccepted: true,
    });
  }

  // ✅ Boden Neu-Belag must be exclusive (one only)
  function ensureBodenNeuBelagExclusive(choice: BelagChoice) {
    const next: BodenState = {
      ...props.boden,

      neuTeppichOn: false,
      neuTeppichDepsAccepted: false,

      neuLaminatOn: false,
      neuLaminatDepsAccepted: false,

      neuParkettOn: false,
      neuParkettDepsAccepted: false,
    };

    if (choice === "teppich") {
      next.neuTeppichOn = true;
      next.neuTeppichDepsAccepted = true;
    } else if (choice === "laminat") {
      next.neuLaminatOn = true;
      next.neuLaminatDepsAccepted = true;
    } else if (choice === "parkett") {
      next.neuParkettOn = true;
      next.neuParkettDepsAccepted = true;
    }

    props.onBodenChange(next);
  }

  function applyAutoDeps(next: HaustechnikState): HaustechnikState {
    // Befund is needed if ANY technical position is on
    const needsBefund =
      next.heizkoerperOn ||
      next.heizleitungenOn ||
      next.sockelkanalOn ||
      next.fbhOn ||
      next.kuehlHeizdeckeOn ||
      next.filtertauschOn ||
      next.ventilatorOn ||
      next.lueftungszuleitungOn ||
      next.badGesamtOn ||
      next.fallstrangOn ||
      next.kuecheAufputzOn ||
      next.aufzSprossenOn ||
      next.aufzHaengeWCOn ||
      next.aufzDuschtasseOn ||
      next.behindertOn ||
      next.gasPruefungOn ||
      next.gasServiceOn ||
      next.gasThermeNeuOn ||
      next.gasInnenleitungenOn ||
      next.gaszuleitungOn ||
      next.zaehlerplatteOn;

    // auto ON
    if (needsBefund && !next.befundOn) {
      next = { ...next, befundOn: true, befundSource: "auto" };
    }

    // auto OFF only if it was auto
    if (!needsBefund && next.befundOn && next.befundSource === "auto") {
      next = { ...next, befundOn: false, befundSource: null };
    }

    // Heizkörper needed if Heizleitungen/Sockelkanal/FBH is on
    const needsHeizkoerper =
      next.heizleitungenOn || next.sockelkanalOn || next.fbhOn;

    if (needsHeizkoerper && !next.heizkoerperOn) {
      next = {
        ...next,
        heizkoerperOn: true,
        heizkoerperSource: "auto",
        heizkoerperDepsAccepted: false, // must be accepted
      };
    }

    if (
      !needsHeizkoerper &&
      next.heizkoerperOn &&
      next.heizkoerperSource === "auto"
    ) {
      next = {
        ...next,
        heizkoerperOn: false,
        heizkoerperSource: null,
        heizkoerperDepsAccepted: false,
      };
    }

    return next;
  }

  // -----------------------------
  // Heizung handlers
  // -----------------------------
  const setBefund = (v: boolean) =>
    update({ befundOn: v, befundSource: v ? "manual" : null });

  const setHeizkoerper = (v: boolean) => {
    if (!v) {
      update({
        heizkoerperOn: false,
        heizkoerperSource: null,
        heizkoerperDepsAccepted: false,
      });
      return;
    }

    // Turn on the position, but require explicit Hinweis-acceptance.
    update({
      befundOn: true,
      befundSource: s.befundOn ? s.befundSource : "auto",
      heizkoerperOn: true,
      heizkoerperSource: "manual",
      heizkoerperDepsAccepted: false,
    });
  };

  const setHeizleitungen = (v: boolean) => {
    if (!v) {
      // remove cross-gewerk deps that were added by Heizleitungen (ref-count)
      bumpAbbruchBelag(-1);
      bumpEstrichNeu(-1, false);

      update({
        heizleitungenOn: false,
        heizleitungenDepsAccepted: false,
        sockelkanalOn: false,
        sockelkanalDepsAccepted: false,
        fbhOn: false,
        fbhDepsAccepted: false,
      });
      return;
    }

    const belag: BelagChoice =
      s.heizleitungenBelag === "none" ? "teppich" : s.heizleitungenBelag;

    // turn ON but require acceptance (Hinweis)
    update({
      heizleitungenOn: true,
      heizleitungenSource: "manual",
      heizleitungenBelag: belag,
      heizleitungenDepsAccepted: false,

      // dependencies ON (auto) but still require their acceptance too
      befundOn: true,
      befundSource: s.befundOn ? s.befundSource : "auto",

      heizkoerperOn: true,
      heizkoerperSource: s.heizkoerperOn ? s.heizkoerperSource : "auto",
      heizkoerperDepsAccepted: s.heizkoerperDepsAccepted, // do not auto-accept
    });

    // only sync to other Gewerke AFTER acceptance + belag ok
    // (we'll trigger this when user accepts below)
  };

  const setBelag = (v: BelagChoice) => {
    update({ heizleitungenBelag: v });

    // only sync to other gewerke if Heizleitungen already accepted/on
    if (s.heizleitungenOn && s.heizleitungenDepsAccepted && v !== "none") {
      // required (next gewerke) – add ref-count deps
      bumpAbbruchBelag(+1);
      bumpEstrichNeu(+1, true);
      ensureBodenNeuBelagExclusive(belag);
    }
  };

  const setSockelkanal = (v: boolean) => {
    if (!v) {
      update({ sockelkanalOn: false, sockelkanalDepsAccepted: false });
      return;
    }
    // requires Heizleitungen + Heizkörper
    if (!s.heizleitungenOn || !s.heizleitungenDepsAccepted)
      setHeizleitungen(true);
    if (!s.heizkoerperOn || !s.heizkoerperDepsAccepted) setHeizkoerper(true);

    update({ sockelkanalOn: true, sockelkanalDepsAccepted: true });
  };

  const setFbh = (v: boolean) => {
    if (!v) {
      update({ fbhOn: false, fbhDepsAccepted: false });
      return;
    }

    // requires Heizleitungen + Heizkörper + Abbruch Estrich + Abbruch Belag
    if (!s.heizleitungenOn || !s.heizleitungenDepsAccepted)
      setHeizleitungen(true);
    if (!s.heizkoerperOn || !s.heizkoerperDepsAccepted) setHeizkoerper(true);

    ensureAbbruchBelag();
    ensureAbbruchEstrich();

    update({
      fbhOn: true,
      fbhDepsAccepted: true,
      abbruchBelagOn: true,
      abbruchEstrichOn: true,
    });
  };

  const setKuehlHeizdecke = (v: boolean) => {
    if (!v) {
      update({ kuehlHeizdeckeOn: false, kuehlHeizdeckeDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      kuehlHeizdeckeOn: true,
      kuehlHeizdeckeDepsAccepted: true,
    });
  };

  // -----------------------------
  // Lüftung handlers
  // -----------------------------
  const setFilter = (v: boolean) => {
    if (!v) {
      update({ filtertauschOn: false, filtertauschDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      filtertauschOn: true,
      filtertauschDepsAccepted: true,
    });
  };

  const setVentilator = (v: boolean) => {
    if (!v) {
      update({ ventilatorOn: false, ventilatorDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      ventilatorOn: true,
      ventilatorDepsAccepted: true,
    });
  };

  // -----------------------------
  // Sanitär handlers
  // -----------------------------
  const setBadGesamt = (v: boolean) => {
    if (!v) {
      update({
        badGesamtOn: false,
        badGesamtDepsAccepted: false,
        aufzSprossenOn: false,
        aufzHaengeWCOn: false,
        aufzDuschtasseOn: false,
        behindertOn: false,
      });
      return;
    }

    update({ befundOn: true, badGesamtOn: true, badGesamtDepsAccepted: true });

    // required
    ensureAbbruchBelag();
    ensureEstrichNeu();
    ensureFliesenBadWc();
  };

  const setFallstrang = (v: boolean) => {
    if (!v) {
      update({ fallstrangOn: false, fallstrangDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      fallstrangOn: true,
      fallstrangDepsAccepted: true,
    });
  };

  const setKuecheAufputz = (v: boolean) => {
    if (!v) {
      update({ kuecheAufputzOn: false, kuecheAufputzDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      kuecheAufputzOn: true,
      kuecheAufputzDepsAccepted: true,
    });
  };

  // -----------------------------
  // Gas handlers
  // -----------------------------
  const setGasPruefung = (v: boolean) => {
    if (!v) {
      update({ gasPruefungOn: false, gasPruefungDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      gasPruefungOn: true,
      gasPruefungDepsAccepted: true,
    });
  };

  const setGasService = (v: boolean) => {
    if (!v) {
      update({ gasServiceOn: false, gasServiceDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      gasServiceOn: true,
      gasServiceDepsAccepted: true,
    });
  };

  const setGasThermeNeu = (v: boolean) => {
    if (!v) {
      update({ gasThermeNeuOn: false, gasThermeNeuDepsAccepted: false });
      return;
    }
    update({
      befundOn: true,
      gasThermeNeuOn: true,
      gasThermeNeuDepsAccepted: true,
    });
  };

  const setGasInnenleitungen = (v: boolean) => {
    if (!v) {
      update({
        gasInnenleitungenOn: false,
        gasInnenleitungenDepsAccepted: false,
      });
      return;
    }
    update({
      befundOn: true,
      gasInnenleitungenOn: true,
      gasInnenleitungenDepsAccepted: true,
    });
  };

  function bumpAbbruchBelag(delta: number) {
    const cur = props.abbruch;
    const nextCount = Math.max(0, (cur.belagAutoCount ?? 0) + delta);

    let belagMode = cur.belagMode;
    let belagSource = cur.belagSource ?? null;

    // auto ON
    if (nextCount > 0 && belagMode === "off") {
      belagMode = "voll";
      belagSource = "auto";
    }

    // auto OFF (only if auto)
    if (nextCount === 0 && belagSource === "auto") {
      belagMode = "off";
      belagSource = null;
    }

    props.onAbbruchChange({
      ...cur,
      belagAutoCount: nextCount,
      belagMode,
      belagSource,
    });
  }

  function bumpAbbruchEstrich(delta: number) {
    const cur = props.abbruch;
    const nextCount = Math.max(0, (cur.estrichAutoCount ?? 0) + delta);

    let estrichMode = cur.estrichMode;
    let estrichSource = cur.estrichSource ?? null;

    if (nextCount > 0 && estrichMode === "off") {
      estrichMode = "voll";
      estrichSource = "auto";
    }

    if (nextCount === 0 && estrichSource === "auto") {
      estrichMode = "off";
      estrichSource = null;
    }

    props.onAbbruchChange({
      ...cur,
      estrichAutoCount: nextCount,
      estrichMode,
      estrichSource,
    });
  }

  return (
    <Modal
      open={props.open}
      title={pb.meta.title}
      subtitle={pb.meta.subtitle}
      onClose={props.onClose}
    >
      <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
        <div className="text-xs text-slate-400">Zusätzliche Anmerkung</div>
        <textarea
          value={s.note}
          onChange={(e) => props.onChange({ ...s, note: e.target.value })}
          className="mt-2 min-h-[90px] w-full resize-y rounded-2xl bg-white/5 px-4 py-3 text-sm ring-1 ring-white/10 outline-none placeholder:text-slate-500 focus:ring-white/20"
          placeholder="..."
        />
      </div>
      <div className="grid gap-5">
        {/* Wohnfläche */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold">Wohnfläche</div>
              <div className="mt-1 text-xs text-slate-400">
                m²-Staffel wird nach Wohnfläche berechnet.
              </div>
            </div>
            <div className="text-sm font-semibold">{m2.toFixed(1)} m²</div>
          </div>
        </div>

        {/* Befund */}
        <ToggleRow
          title={pb.befund.title}
          description={pb.befund.description}
          checked={s.befundOn}
          price={parts.befundPrice}
          disabled={m2 <= 0}
          onToggle={setBefund}
        />

        {/* Heizung */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="text-sm font-semibold">Heizung</div>
          <div className="mt-4 grid gap-3">
            <ToggleRow
              title={pb.heizkoerper_tausch.title}
              description={pb.heizkoerper_tausch.description}
              checked={s.heizkoerperOn}
              price={parts.heizkoerper}
              disabled={m2 <= 0}
              onToggle={setHeizkoerper}
            >
              {/* Hinweis-Akzeptanz (Position 2) */}
              <div className="rounded-2xl bg-amber-900/20 ring-1 ring-amber-500/30 p-3">
                <div className="text-xs text-amber-200 whitespace-pre-line">
                  Diese Position erfordert eine <b>Befundaufnahme</b>.
                  <br />
                  Bitte bestätigen, dass du diesen Hinweis gelesen und
                  akzeptiert hast.
                </div>

                <label className="mt-3 flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={s.heizkoerperDepsAccepted}
                    onChange={(e) =>
                      update({ heizkoerperDepsAccepted: e.target.checked })
                    }
                  />
                  Ich habe den Hinweis gelesen und akzeptiere ihn
                </label>

                {!s.heizkoerperDepsAccepted ? (
                  <div className="mt-2 text-xs text-amber-200/80">
                    *Ohne Bestätigung wird diese Position mit 0,00 € berechnet.
                  </div>
                ) : null}
              </div>
            </ToggleRow>

            <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-sm font-semibold">
                    {pb.heizleitungen_tausch.title}
                  </div>
                  <div className="mt-1 text-xs text-slate-400 whitespace-pre-line">
                    {pb.heizleitungen_tausch.description}
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-sm font-semibold">
                    {formatEUR(parts.heizleitungen)}
                  </div>
                  <Switch
                    checked={s.heizleitungenOn}
                    disabled={m2 <= 0}
                    onChange={setHeizleitungen}
                  />
                </div>
              </div>

              {s.heizleitungenOn ? (
                <div className="mt-4 grid gap-3 lg:grid-cols-2">
                  <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
                    <div className="text-xs text-slate-400">
                      Neuer Belag (Pflicht)
                    </div>
                    <div className="rounded-3xl bg-amber-900/20 ring-1 ring-amber-500/30 p-4">
                      <div className="text-xs text-amber-200 whitespace-pre-line">
                        Diese Position erfordert eine <b>Befundaufnahme</b>{" "}
                        sowie den
                        <b> Heizkörpertausch</b>. Zusätzlich sind Estrich &
                        Boden-Belag herzustellen (Pflichtauswahl).
                        <br />
                        Bitte bestätigen, dass du diesen Hinweis gelesen und
                        akzeptiert hast.
                      </div>

                      <label className="mt-3 flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={s.heizleitungenDepsAccepted}
                          onChange={(e) => {
                            const accepted = e.target.checked;

                            update({ heizleitungenDepsAccepted: accepted });

                            // when user accepts AND belag ok -> sync to other Gewerke
                            if (accepted && s.heizleitungenBelag !== "none") {
                              ensureAbbruchBelag();
                              ensureEstrichNeu();
                              ensureBodenNeuBelagExclusive(
                                s.heizleitungenBelag,
                              );
                            }
                          }}
                        />
                        Ich habe den Hinweis gelesen und akzeptiere ihn
                      </label>

                      {!s.heizleitungenDepsAccepted ? (
                        <div className="mt-2 text-xs text-amber-200/80">
                          *Ohne Bestätigung wird diese Position mit 0,00 €
                          berechnet.
                        </div>
                      ) : null}
                    </div>

                    <select
                      value={s.heizleitungenBelag}
                      onChange={(e) => setBelag(e.target.value as BelagChoice)}
                      className="mt-2 w-full rounded-2xl bg-slate-900 text-slate-100 px-4 py-3 text-sm ring-1 ring-white/10 outline-none focus:ring-white/20"
                    >
                      <option
                        className="bg-slate-900 text-slate-100"
                        value="none"
                      >
                        Bitte wählen…
                      </option>
                      <option
                        className="bg-slate-900 text-slate-100"
                        value="teppich"
                      >
                        Teppich
                      </option>
                      <option
                        className="bg-slate-900 text-slate-100"
                        value="laminat"
                      >
                        Laminat
                      </option>
                      <option
                        className="bg-slate-900 text-slate-100"
                        value="parkett"
                      >
                        Parkett
                      </option>
                    </select>

                    {!parts.belagOk ? (
                      <div className="mt-2 text-xs text-amber-300">
                        Belag-Auswahl ist erforderlich.
                      </div>
                    ) : null}
                  </div>

                  <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
                    <div className="text-xs text-slate-400">
                      Auto-Dependencies
                    </div>
                    <div className="mt-2 text-xs text-slate-300">
                      Boden (Neu-Belag): wird automatisch exklusiv gesetzt.
                      <br />
                      Estrich (Neu): wird automatisch aktiviert.
                      <br />
                      Abbruch (Belag): wird automatisch aktiviert.
                    </div>
                  </div>
                </div>
              ) : null}
            </div>

            <ToggleRow
              title={pb.aufz_sockelkanal.title}
              description={pb.aufz_sockelkanal.description}
              checked={s.sockelkanalOn}
              price={parts.sockelkanal}
              disabled={m2 <= 0}
              onToggle={setSockelkanal}
              extraRight={
                !s.heizleitungenOn ||
                !s.heizleitungenDepsAccepted ||
                !s.heizkoerperOn ||
                !s.heizkoerperDepsAccepted ? (
                  <span className="text-[11px] text-amber-300">
                    setzt Heizleitungen+Heizkörper
                  </span>
                ) : null
              }
            />

            <ToggleRow
              title={pb.aufz_fbh.title}
              description={pb.aufz_fbh.description}
              checked={s.fbhOn}
              price={parts.fbh}
              disabled={m2 <= 0}
              onToggle={setFbh}
              extraRight={
                props.abbruch.estrichMode === "off" ||
                props.abbruch.belagMode === "off" ? (
                  <span className="text-[11px] text-amber-300">
                    setzt Abbruch Estrich+Belag
                  </span>
                ) : null
              }
            />

            <ToggleRow
              title={pb.kuehl_heizdecke.title}
              description={`${pb.kuehl_heizdecke.description} (${formatEUR(pb.kuehl_heizdecke.perM2)}/m²)`}
              checked={s.kuehlHeizdeckeOn}
              price={parts.kuehlHeizdecke}
              disabled={m2 <= 0}
              onToggle={setKuehlHeizdecke}
            />
          </div>
        </div>

        {/* Lüftung */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="text-sm font-semibold">Lüftung</div>
          <div className="mt-4 grid gap-3">
            <ToggleRow
              title={pb.lueftung_filter.title}
              description={pb.lueftung_filter.description}
              checked={s.filtertauschOn}
              price={parts.filtertausch}
              disabled={m2 <= 0}
              onToggle={setFilter}
            />

            <ToggleRow
              title={pb.lueftung_ventilator.title}
              description={pb.lueftung_ventilator.description}
              checked={s.ventilatorOn}
              price={parts.ventilator}
              onToggle={setVentilator}
            />

            <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold">
                    {pb.lueftungszuleitung.title}
                  </div>
                  <div className="mt-1 text-xs text-slate-400">
                    {formatEUR(pb.lueftungszuleitung.base)} +{" "}
                    {formatEUR(pb.lueftungszuleitung.unitPrice)}/lfm
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-sm font-semibold">
                    {formatEUR(parts.lueftungszuleitung)}
                  </div>
                  <Switch
                    checked={s.lueftungszuleitungOn}
                    onChange={(v) => update({ lueftungszuleitungOn: v })}
                  />
                </div>
              </div>

              {s.lueftungszuleitungOn ? (
                <div className="mt-4">
                  <QtyInput
                    label="Laufmeter (lfm)"
                    unitBadge="lfm"
                    step={0.1}
                    value={s.lueftungszuleitungLfm}
                    onChange={(v) => update({ lueftungszuleitungLfm: v })}
                  />
                </div>
              ) : null}
            </div>
          </div>
        </div>

        {/* Sanitär */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="text-sm font-semibold">Sanitär</div>
          <div className="mt-4 grid gap-3">
            <ToggleRow
              title={pb.sanitaer_bad_gesamt.title}
              description={pb.sanitaer_bad_gesamt.description}
              checked={s.badGesamtOn}
              price={parts.badGesamt}
              onToggle={setBadGesamt}
              extraRight={
                props.fliesen.neuBadWcOn && props.estrich.neuOn ? (
                  <span className="text-[11px] text-emerald-300">
                    Fliesen+Estrich OK
                  </span>
                ) : (
                  <span className="text-[11px] text-amber-300">
                    setzt Fliesen+Estrich
                  </span>
                )
              }
            />

            <ToggleRow
              title={pb.sanitaer_fallstrang.title}
              description={pb.sanitaer_fallstrang.description}
              checked={s.fallstrangOn}
              price={parts.fallstrang}
              onToggle={setFallstrang}
            />

            <ToggleRow
              title={pb.sanitaer_kueche_aufputz.title}
              description={pb.sanitaer_kueche_aufputz.description}
              checked={s.kuecheAufputzOn}
              price={parts.kuecheAufputz}
              onToggle={setKuecheAufputz}
            />

            {/* simple sanitär toggles (no description fields needed for small items) */}
            <ToggleRow
              title={pb.sanitaer_zus_dusche.title}
              checked={s.zusDuscheOn}
              price={parts.zusDusche}
              onToggle={(v) => update({ zusDuscheOn: v })}
            />
            <ToggleRow
              title={pb.aufz_vollglas.title}
              checked={s.vollglasOn}
              price={parts.vollglas}
              disabled={!s.zusDuscheOn}
              onToggle={(v) => update({ vollglasOn: v })}
            />
            <ToggleRow
              title={pb.sanitaer_zus_wt.title}
              checked={s.zusWTOn}
              price={parts.zusWT}
              onToggle={(v) => update({ zusWTOn: v })}
            />
            <ToggleRow
              title={pb.sanitaer_wt_tausch.title}
              checked={s.wtTauschOn}
              price={parts.wtTausch}
              onToggle={(v) => update({ wtTauschOn: v })}
            />
            <ToggleRow
              title={pb.sanitaer_wc_tausch.title}
              checked={s.wcTauschOn}
              price={parts.wcTausch}
              onToggle={(v) => update({ wcTauschOn: v })}
            />
            <ToggleRow
              title={pb.sanitaer_wanne_dusche_tausch.title}
              checked={s.wanneDuscheTauschOn}
              price={parts.wanneDuscheTausch}
              onToggle={(v) => update({ wanneDuscheTauschOn: v })}
            />
            <ToggleRow
              title={pb.sanitaer_gebrauch.title}
              checked={s.gebrauchOn}
              price={parts.gebrauch}
              onToggle={(v) => update({ gebrauchOn: v })}
            />

            <ToggleRow
              title={pb.aufz_sprossen_e.title}
              description={pb.aufz_sprossen_e.description}
              checked={s.aufzSprossenOn}
              price={parts.aufzSprossen}
              disabled={!s.badGesamtOn}
              onToggle={(v) => update({ aufzSprossenOn: v })}
            />
            <ToggleRow
              title={pb.aufz_haenge_wc.title}
              description={pb.aufz_haenge_wc.description}
              checked={s.aufzHaengeWCOn}
              price={parts.aufzHaengeWC}
              disabled={!s.badGesamtOn}
              onToggle={(v) => update({ aufzHaengeWCOn: v })}
            />
            <ToggleRow
              title={pb.aufz_duschtasse.title}
              description={pb.aufz_duschtasse.description}
              checked={s.aufzDuschtasseOn}
              price={parts.aufzDuschtasse}
              disabled={!s.badGesamtOn}
              onToggle={(v) => update({ aufzDuschtasseOn: v })}
            />
            <ToggleRow
              title={pb.behindertengerecht.title}
              description={pb.behindertengerecht.description}
              checked={s.behindertOn}
              price={parts.behindert}
              disabled={
                !s.badGesamtOn || !s.aufzDuschtasseOn || !s.aufzHaengeWCOn
              }
              onToggle={(v) => update({ behindertOn: v })}
            />

            <ToggleRow
              title={pb.klappsitz.title}
              checked={s.klappsitzOn}
              price={parts.klappsitz}
              onToggle={(v) => update({ klappsitzOn: v })}
            />
            <ToggleRow
              title={pb.armatur.title}
              checked={s.armaturOn}
              price={parts.armatur}
              onToggle={(v) => update({ armaturOn: v })}
            />
            <ToggleRow
              title={pb.wc_sensor.title}
              checked={s.wcSensorOn}
              price={parts.wcSensor}
              onToggle={(v) => update({ wcSensorOn: v })}
            />
            <ToggleRow
              title={pb.gebrauch_2.title}
              checked={s.gebrauch2On}
              price={parts.gebrauch2}
              onToggle={(v) => update({ gebrauch2On: v })}
            />
            <ToggleRow
              title={pb.untertisch_10l.title}
              checked={s.untertisch10lOn}
              price={parts.untertisch10l}
              onToggle={(v) => update({ untertisch10lOn: v })}
            />
            <ToggleRow
              title={pb.e_speicher.title}
              checked={s.eSpeicherOn}
              price={parts.eSpeicher}
              onToggle={(v) => update({ eSpeicherOn: v })}
            />
          </div>
        </div>

        {/* Gas */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="text-sm font-semibold">Gas</div>
          <div className="mt-4 grid gap-3">
            <ToggleRow
              title={pb.gas_pruefung.title}
              description={pb.gas_pruefung.description}
              checked={s.gasPruefungOn}
              price={parts.gasPruefung}
              onToggle={setGasPruefung}
            />
            <ToggleRow
              title={pb.gas_service.title}
              description={pb.gas_service.description}
              checked={s.gasServiceOn}
              price={parts.gasService}
              onToggle={setGasService}
            />
            <ToggleRow
              title={pb.gas_therme_neu.title}
              description={pb.gas_therme_neu.description}
              checked={s.gasThermeNeuOn}
              price={parts.gasThermeNeu}
              onToggle={setGasThermeNeu}
            />
            <ToggleRow
              title={pb.gas_innenleitungen.title}
              description={pb.gas_innenleitungen.description}
              checked={s.gasInnenleitungenOn}
              price={parts.gasInnenleitungen}
              onToggle={setGasInnenleitungen}
              disabled={m2 <= 0}
            />

            <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold">
                    {pb.gaszuleitung.title}
                  </div>
                  <div className="mt-1 text-xs text-slate-400">
                    {formatEUR(pb.gaszuleitung.base)} +{" "}
                    {formatEUR(pb.gaszuleitung.unitPrice)}/lfm
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-sm font-semibold">
                    {formatEUR(parts.gaszuleitung)}
                  </div>
                  <Switch
                    checked={s.gaszuleitungOn}
                    onChange={(v) => update({ gaszuleitungOn: v })}
                  />
                </div>
              </div>

              {s.gaszuleitungOn ? (
                <div className="mt-4">
                  <QtyInput
                    label="Laufmeter (lfm)"
                    unitBadge="lfm"
                    step={0.1}
                    value={s.gaszuleitungLfm}
                    onChange={(v) => update({ gaszuleitungLfm: v })}
                  />
                </div>
              ) : null}
            </div>
          </div>
        </div>

        {/* Zählerplatte */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="text-sm font-semibold">Zählerplatte</div>

          <div className="mt-4 rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-sm font-semibold">
                  {pb.zaehlerplatte.title}
                </div>
                <div className="mt-1 text-xs text-slate-400">
                  {formatEUR(pb.zaehlerplatte.base)} +{" "}
                  {formatEUR(pb.zaehlerplatte.unitPrice)}/st
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-sm font-semibold">
                  {formatEUR(parts.zaehlerplatte)}
                </div>
                <Switch
                  checked={s.zaehlerplatteOn}
                  onChange={(v) => update({ zaehlerplatteOn: v })}
                />
              </div>
            </div>

            {s.zaehlerplatteOn ? (
              <div className="mt-4">
                <QtyInput
                  label="Stück"
                  unitBadge="st"
                  step={1}
                  value={s.zaehlerplatteQty}
                  onChange={(v) => update({ zaehlerplatteQty: Math.floor(v) })}
                />
              </div>
            ) : null}
          </div>
        </div>

        {/* Total */}
        <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center justify-between">
            <div className="text-sm text-slate-300">Summe Haustechnik</div>
            <div className="text-lg font-semibold">
              {formatEUR(parts.total)}
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}
