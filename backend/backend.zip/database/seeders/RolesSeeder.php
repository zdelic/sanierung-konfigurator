<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        $perms = [
            'pricebook.view',
            'pricebook.edit',
            'projects.view',
            'projects.edit',
            'projects.delete',
            'users.manage',
        ];

        foreach ($perms as $p) {
            Permission::findOrCreate($p);
        }

        $admin  = Role::findOrCreate('admin');
        $editor = Role::findOrCreate('editor');
        $viewer = Role::findOrCreate('viewer');

        $admin->syncPermissions($perms);
        $editor->syncPermissions(['pricebook.view', 'projects.view', 'projects.edit']);
        $viewer->syncPermissions(['pricebook.view', 'projects.view']);
    }
}
